﻿//using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using System.Linq;
using DG.Tweening;
using System;
using System.IO;
using UnityEngine.UI;
using static Utility;

namespace MainMap
{
    public class MapSquad : MonoBehaviour
    {
        /// <summary>
        /// 蜑埼擇縺ｫ陦ｨ遉ｺ縺輔ｌ繧気ollider莉倥″縺ｮObject
        /// </summary>
        [SerializeField] internal GameObject ImagePanel;

        [SerializeField] internal Transform progressbarPosition;

        /// <summary>
        /// Squad縺後Ο繧ｱ繝ｼ繧ｷ繝ｧ繝ｳ縺ｮ荳翫↓縺�繧九°縺ｩ縺�縺�
        /// </summary>
        [SerializeField, ReadOnly] internal bool isOnLocation = false;
        [Tooltip("Squad縺ｮ遘ｻ蜍輔せ繝斐�ｼ繝�")]
        [SerializeField] float speed = 0.06f;

        /// <summary>
        /// SpawnPoint荳翫↓菴咲ｽｮ縺励※縺�繧九→蛻､譁ｭ縺輔ｌ繧玖ｷ晞屬
        /// </summary>
        readonly float DistanceOfLocateOnSpawnPoint = 0.02f;

        /// <summary>
        /// Squads縺ｮ繝代Λ繝｡繝ｼ繧ｿ繝ｼ
        /// </summary>
        internal Squad data;
        /// <summary>
        /// 菴懈�先凾縺ｫ貂｡縺輔ｌ繧貴apData
        /// </summary>
        internal MapLocations mapLocations;
        /// <summary>
        /// 霆瑚ｷ｡縺ｮ莉･蜑阪�ｮ謠丞�吶ｒ陦後▲縺殫osition 雋�闕ｷ霆ｽ貂帙�ｮ縺溘ａdrawTranjectoryDistance莉･荳九�ｮ遘ｻ蜍輔〒縺ｯ霆瑚ｷ｡縺ｮ謠丞�吶ｒ陦後ｏ縺ｪ縺�
        /// </summary>
        private Vector3 previousTrajectoryPos;
        /// <summary>
        /// 霆瑚ｷ｡繧呈峩譁ｰ縺吶ｋ繝槭え繧ｹ繝昴ず繧ｷ繝ｧ繝ｳ縺ｮ逶ｴ邱夊ｷ晞屬
        /// </summary>
        private float drawTrajectoryDistance = 50;
        /// <summary>
        /// 遘ｻ蜍穂ｸｭ縺九←縺�縺九�ｮ蛻､螳�
        /// </summary>
        public bool IsMoving { private set; get; } = false;
        /// <summary>
        /// 繝�繝舌ャ繧ｯ逕ｨ縺ｮ蜃ｺ蜉帙ｒ縺吶ｋ縺�
        /// </summary>
        private readonly bool DEBUG = false;
        /// <summary>
        /// Squad縺梧怙蠕後↓菴咲ｽｮ縺励◆諡�轤ｹ縺九ｉ縺ｮ邱冗ｧｻ蜍戊ｷ晞屬
        /// </summary>
        private float moveDistance = 0;
        /// <summary>
        /// Squad縺ｮSupply縺梧怙蠕後↓蠑輔°繧後◆菴咲ｽｮ縺九ｉ縺ｮ遘ｻ蜍戊ｷ晞屬
        /// </summary>
        private float prevDistance = 0;
        /// <summary>
        /// 謫堺ｽ懷庄閭ｽ縺ｪSquad縺九←縺�縺� 繧｢繝九Γ繝ｼ繧ｷ繝ｧ繝ｳ荳ｭ縺ｪ縺ｩ縺ｯ繧ｳ繝ｳ繝医Ο繝ｼ繝ｫ荳榊庄
        /// </summary>
        public bool IsControllable { private set; get; } = true;
        /// <summary>
        /// 豁ｩ陦後′邨ゅｏ縺｣縺ｦ縺九ｉ縺ｮ邨碁℃譎る俣  (Walk荳ｭ縺ｨ縺昴ｌ縺檎ｵゅｏ縺｣縺ｦ荳螳壽凾髢薙�ｯWait縺ｮSupply貂帛ｰ代ｒ襍ｷ縺薙＆縺ｪ縺�)
        /// </summary>
        private float timeBeforeWalk = 0;
        /// <summary>
        /// 繧ｹ繝昴�ｼ繝ｳ繧ゅ＠縺上�ｯ豁ｩ陦御ｸｭ縺ｨ縺昴ｌ縺檎ｵゅｏ縺｣縺ｦ荳螳壽凾髢薙�ｯWait縺ｫ繧医ｋSupply貂帛ｰ代ｒ襍ｷ縺薙＆縺ｪ縺�
        /// </summary>
        private bool lockReducingSupply = true;
        /// <summary>
        /// 繧ｹ繝昴�ｼ繝ｳ繧ゅ＠縺上�ｯ豁ｩ陦檎ｵゆｺ�蠕後�ｮSupply縺ｮ貂帛ｰ代′繝ｭ繝�繧ｯ縺輔ｌ繧区凾髢薙�ｮ繧､繝ｳ繧ｿ繝ｼ繝舌Ν
        /// </summary>
        private readonly float intervalLockReducingSupply = 30;
        /// <summary>
        /// Squad縺檎ｧｻ蜍輔☆繧矩圀縺ｮ繧｢繝九Γ繝ｼ繧ｷ繝ｧ繝ｳSquad
        /// </summary>
        internal Sequence moveSequence;
        private Action onCompleteMoveSequence;
        /// <summary>
        /// Squad縺檎ｧｻ蜍輔☆繧却ath
        /// </summary>
        internal List<Transform> squadMoveCheckPoints;
        /// <summary>
        /// 繧ｹ繝昴�ｼ繝ｳ蝨ｰ轤ｹ繧呈欠螳壹☆繧九◆繧√↓Unit繧偵き繝ｼ繧ｽ繝ｫ縺ｫ霑ｽ蠕薙＠縺ｦLocation繧呈欠螳壹☆繧句ｽ｢縺ｫ縺吶ｋ
        /// </summary>
        internal bool IsSpawnMode
        {
            get => _IsSpawnMode;
            set
            {
                ImagePanel.SetActive(!value);
                _IsSpawnMode = value;
            }
        }
        private bool _IsSpawnMode = false;
        /// <summary>
        /// Squad縺郡pawnPoint縺ｮ荳翫↓縺�繧句�ｴ蜷医�ｮID
        /// </summary>
        public string SpawnPointLocated { private set; get; } = "";
        /// <summary>
        /// Squad縺郡pawnPoint荳翫↓蛻ｰ驕斐＠縺溘→縺阪↓蜻ｼ縺ｳ蜃ｺ縺�
        /// </summary>
        internal Action<Roads.MapSpawnLocation, MapSquad> SquadReachedOnSpawnPoint;

        // Squad縺薫verlaycanvas縺ｫ陦ｨ遉ｺ縺吶ｋ2D繝代ロ繝ｫ
        /// <summary>
        /// overlayCanvas縺ｮ荳翫↓縺ゅｋSquad縺ｮ隕九◆逶ｮ縺ｮ縺溘ａ縺ｮ繧ゅ�ｮ
        /// </summary>
        internal RectTransform Panel
        {
            get => panel;
            set
            {
                panel = value;
                var rects = GetComponentsInChildren<RectTransform>().ToList();
                locationPanel = rects.Find(r => r.name == "LocationIcon");
                manPanel = rects.Find(r => r.name == "ManIcon");
                manPanelImage = manPanel.GetComponent<Image>();

                
            }
        }
        private RectTransform panel;
        private RectTransform locationPanel;
        private RectTransform manPanel;
        private Image manPanelImage;

        GeneralParameter parameter;
        GameManager GameManager;

        Camera Camera;

        protected private void Awake()
        {
            previousTrajectoryPos = gameObject.transform.position;
            parameter = GameManager.Instance.generalParameter;
            GameManager = GameManager.Instance;
            Camera = Camera.main;
        }

        protected private void Update()
        {
            timeBeforeWalk += Time.deltaTime;

            // 豁ｩ陦悟ｾ後�ｮSupplyLock繧､繝ｳ繧ｿ繝ｼ繝舌Ν
            //if (!IsMoving && lockReducingSupply)
            //{
            //    if (timeBeforeWalk > intervalLockReducingSupply)
            //        lockReducingSupply = false;
            //}
        }


        /// <summary>
        /// Squad繧帝∈謚槭＠縺溘→縺阪�ｮ蜍穂ｽ�
        /// </summary>
        internal void SelectSquad()
        {
            // print($"Select: {info.name}");
        }

        /// <summary>
        /// Squad縺ｮ驕ｸ謚槭′隗｣髯､縺輔ｌ縺溘→縺阪�ｮ蜍穂ｽ�
        /// </summary>
        internal void DeSelectSquad()
        {
            
        }

        /// <summary>
        /// Squad縺悟渕蝨ｰ縺ｫ謌ｻ繧九→縺阪↓MapSquads縺九ｉ蜻ｼ縺ｳ蜃ｺ縺輔ｌ繧�
        /// </summary>
        internal IEnumerator AnimationReturnToBase()
        {
            IsControllable = false;
            yield return transform.DOScale(Vector3.zero, 1.5f).WaitForCompletion();
        }

        /// <summary>
        /// Squad縺悟ｼｷ蛻ｶ逧�縺ｫ蟶ｰ驍�縺輔ｌ縺溘→縺阪�ｮ繧｢繝九Γ繝ｼ繧ｷ繝ｧ繝ｳ
        /// </summary>
        /// <returns></returns>
        internal IEnumerator AnimationReturnToBaseForced()
        {
            IsControllable = false;
            yield return transform.DOScale(Vector3.zero, 1.5f).WaitForCompletion();
        }

        /// <summary>
        /// Squad繧値ocation縺ｫ遘ｻ蜍輔＆縺帙ｋ
        /// </summary>
        /// <param name="location"></param>
        /// <param name="onComplete"></param>
        /// <returns></returns>
        internal IEnumerator MoveAlong(List<Transform> checkPoints, Action onComplete = null)
        {

            bool isMoveCompleted = false;
            if (checkPoints == null || checkPoints.Count == 0)
                yield break;

            void MakeAnimationToGoal()
            {
                moveSequence = DOTween.Sequence();
                for(var i=1; i<checkPoints.Count; i++)
                {
                    var cp0 = checkPoints[i - 1].localPosition;
                    var cp1 = checkPoints[i].localPosition;
                    float distToCP = Vector3.Distance(cp0, cp1);
                    // timeToCP = distToCP / GameController.generalParameters.squadSpeedOnMainMap;
                    var timeToCP = distToCP / speed;
                    var moveAnim = transform.DOLocalMove(cp1, timeToCP);
                    moveAnim.SetEase(Ease.Linear);
                    moveSequence.Append(moveAnim);
                }

                moveSequence.OnComplete(() => isMoveCompleted = true);
                onCompleteMoveSequence = onComplete;
            }

            var positionOfCheckPoint = checkPoints.Last().position;
            MakeAnimationToGoal();
            IsMoving = true;
            moveSequence.Play();

            
            var isOnSpawnPoint = false;
            while (!isMoveCompleted)
            {
                foreach(var l in mapLocations.mapSpawnLocations)
                {
                    var distToSpawnPoint = Vector3.Distance(transform.position, l.transform.position);
                    if (distToSpawnPoint < DistanceOfLocateOnSpawnPoint)
                    {
                        isOnSpawnPoint = true;
                        if (SpawnPointLocated != l.SpawnID)
                        {
                            SpawnPointLocated = l.SpawnID;
                            SquadReachedOnSpawnPoint?.Invoke(l, this);
                        }
                        break;
                    }
                }
                if (!isOnSpawnPoint)
                {
                    // 縺ｩ縺ｮSpawnPoint荳翫↓繧ょｭ伜惠縺励※縺�縺ｪ縺�
                    SpawnPointLocated = "";
                }
                moveSequence.timeScale = GameManager.speed;

                yield return null;
            }

            IsMoving = false;
            onCompleteMoveSequence = null;
            onComplete?.Invoke();
        }

        /// <summary>
        /// Squad縺ｮ遘ｻ蜍輔い繝九Γ繝ｼ繧ｷ繝ｧ繝ｳ繧偵く繝｣繝ｳ繧ｻ繝ｫ縺吶ｋ
        /// </summary>
        internal void CancelMoveAnimation()
        {
            if (!IsMoving) return;
            moveSequence.Kill();
            onCompleteMoveSequence?.Invoke();
            IsMoving = false;
        }

        /// <summary>
        /// 遘ｻ蜍輔Ο繧ｰ繧剃ｿ晏ｭ倥☆繧狗畑縺ｮclass (Debug逕ｨ)
        /// </summary>
        [Serializable]
        class MoveLog
        {
            public List<SerializableVector3> data = new List<SerializableVector3>();
        }

        /// <summary>
        /// Squad繧偵い繝九Γ繝ｼ繧ｷ繝ｧ繝ｳ縺ｪ縺励↓遘ｻ蜍輔＆縺帙ｋ 迴ｾ蝨ｨ縺ｮ遘ｻ蜍百equence縺後≠繧句�ｴ蜷医�ｯCancel縺輔ｌ繧�
        /// </summary>
        /// <param name="position"></param>
        internal void MoveToWithoutAnimation(Vector3 position)
        {
            if (moveSequence != null && ( moveSequence.IsActive() || moveSequence.IsPlaying()))
                moveSequence.Kill();
            transform.position = position;
        }

        /// <summary>
        /// Squad縺九ｉPosition縺ｸ縺ｮ霆瑚ｷ｡繧呈緒蜀吶☆繧�
        /// </summary>
        /// <param name="mousePosition"></param>
        /// <returns></returns>
        internal IEnumerator DrawTrajectory(Vector3 mousePosition)
        {
            yield return null;
            //if (!gameObject.activeInHierarchy || meshAgent == null)
            //    yield break;

            //// TODO: 霆瑚ｷ｡縺ｮ謠丞�吶�ｯ繧�繧翫°縺�
            //var mouseDistance = Vector3.Distance(mousePosition, previousTrajectoryPos);
            //if (mouseDistance < drawTrajectoryDistance)
            //    yield break;

            //previousTrajectoryPos = mousePosition;

            //var test = meshAgent.SetDestination(mousePosition);

            //while (!meshAgent.hasPath)
            //    yield return null;
            
            //var corners = meshAgent.path.corners.ToList().FindAll(pos =>
            //{
            //    var diff2d = new Vector2(Mathf.Abs(pos.x - transform.position.x),
            //                             Mathf.Abs(pos.z - transform.position.z));
            //    return 0.1f <= diff2d.magnitude;
            //});
            //meshAgent.ResetPath();

            //var previousPos = transform.position;
            //foreach (var point in corners)
            //{
            //    Debug.DrawLine(previousPos, point, Color.red, 0.5f);
            //    previousPos = point;
            //}
        }

        public override string ToString()
        {
            return $"Squad: {data.name}, locate({(data.LocationID.Length != 0 ? data.LocationID : data.RoadID)}, supply({data.supplyLevel})";
        }
    }
}