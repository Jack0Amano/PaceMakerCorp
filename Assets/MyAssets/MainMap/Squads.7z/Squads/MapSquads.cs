﻿using DG.Tweening;
using Parameters.SpawnSquad;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.AddressableAssets;
using static Utility;

namespace MainMap
{
    /// <summary>
    /// 操作可能な自軍のController
    /// </summary>
    public class MapSquads : MonoBehaviour
    {
        [SerializeField] Roads.MapRoads mapRoads;
        [SerializeField] UI.TableOverlay.TableOverlayPanel TableOverlayPanel;
        [SerializeField] RectTransform squadPanelTemplate;
        [SerializeField] GameObject squadPanelParent;
        [SerializeField] private GUIStyle passGuiStyle;

        /// <summary>
        /// Mapの各地点の情報  MainMapControllerより
        /// </summary>
        internal MapLocations MapLocations;
        /// <summary>
        /// スポーンしている敵部隊の情報
        /// </summary>
        internal Spawn.MapSpawns MapSpawns;
        /// <summary>
        /// 情報を表示するためのUIパネル MainMapControllerより
        /// </summary>
        internal MainMap.UI.InfoPanel.SquadsInfoPanel infoPanel;
        /// <summary>
        /// 現在選択中のSquad
        /// </summary>
        internal MapSquad SelectedSquad
        {
            set
            {
                if (_selectedSquad != null)
                    _selectedSquad.DeSelectSquad();

                if (value != null)
                    value.SelectSquad();

                _selectedSquad = value;
            }

            get => _selectedSquad;
        }
        private MapSquad _selectedSquad;
        /// <summary>
        /// Map上に存在する全ての部隊
        /// </summary>
        readonly internal List<MapSquad> squads = new List<MapSquad>();
        /// <summary>
        /// 一時停止中のSquad
        /// </summary>
        private List<MapSquad> pausedSquads = new List<MapSquad>();
        /// <summary>
        /// 出撃地点を決定するためにカーソルに追従するSquad
        /// </summary>
        internal MapSquad ReadySquad;
        /// <summary>
        /// Squadが基地に戻るアニメーションを再生中かどうか
        /// </summary>
        public bool ReturnAnimPlaying { private set; get; } = false;
        /// <summary>
        /// Squadが現在移動中かどうか
        /// </summary>
        public bool IsSquadMoving
        {
            get
            {
                return squads.Find(s => s.IsMoving) != null;
            }
        }
        /// <summary>
        /// 何らかのSquadが出撃準備でLocationの選択中になっているか
        /// </summary>
        public bool IsSquadReadyToGo
        {
            get
            {
                return ReadySquad != null;
            }
        }
        /// <summary>
        /// エンカウントした際のEvent
        /// </summary>
        public EventHandler<EncountEventArgs> encountEventHandler;

        GeneralParameter parameter;
        GameManager GameManager;

        protected private void Awake()
        {
            GameManager = GameManager.Instance;
            parameter = GameManager.generalParameter;
            GameManager.passTimeEventHandlerAsync += TimerNortification;
            GameManager.addTimeEventHandlerAsync += AddTimeNortificationAsync;
            GameManager.addTimeEventHandlerSync += AddTimeNortificationSync;
            TableOverlayPanel.MapSquads = this;
        }

        protected void Update()
        {
        }

        /// <summary>
        /// DataControllerの中身をロードしてMapSquadsに反映させる
        /// </summary>
        internal IEnumerator LoadData()
        {
            // 一旦全てのSquadとObjectを消す
            squads.ForEach((s) => Destroy(s.gameObject));
            squads.Clear();
            pausedSquads.Clear();
            infoPanel.Clear();

            var coroutines = new List<Coroutine>();
            foreach (var squad in GameManager.DataSavingController.MyArmyData.squads)
            {
                if (!squad.isOnMap) continue;
                // 現在出撃中のSquad
                var coroutine = StartCoroutine(PutSquadOnMap(squad));
                coroutines.Add(coroutine);
            }

            // 全てのcoroutineが終了するまで待つ
            foreach (var coroutine in coroutines)
                yield return coroutine;

            squads.ForEach(s => infoPanel.Add(s));
        }

        /// <summary>
        /// <c>timerCallbackSeconds</c>ごとに呼び出されるゲーム内時間のタイマー
        /// </summary>
        /// <param name="o"></param>
        /// <param name="args"></param>
        private void TimerNortification(object o, EventArgs args)
        {
        }

        /// <summary>
        /// <c>ゲーム内時間で1分経過したときに呼び出し</c>
        /// </summary>
        /// <param name="o"></param>
        /// <param name="args"></param>
        private void AddTimeNortificationSync(object o,EventArgs args)
        {
            var dayLengthSecond = parameter.dayLengthMinute * 60;
            var calledCountInDay = dayLengthSecond / GameManager.AddTimeSeconds;

            // Supplyの増減をコントロール
            if (squads.Count != 0)
            {
                // SquadのSupplyタイマー
                var _squads = new List<MapSquad>(squads);
                _squads.ForEach(s =>
                {
                    if (s.data.MapLocation.data.type != LocationParamter.Type.friend)
                    {
                        //if (lockReducingSupply) return;
                        var cost = s.IsMoving ? parameter.SupplyCostWhenWalking : parameter.SupplyCostWhenWaiting;
                        cost /= calledCountInDay;
                        s.data.supplyLevel -= cost;
                        if (s.data.supplyLevel <= 0)
                        {
                            s.data.supplyLevel = 0;
                            // TODO: SupplyLevelが0以下になったため帰還させる
                            StartCoroutine(s.AnimationReturnToBaseForced());
                            SquadReturnToNearBase(s, true);
                        }
                        else
                        {
                            // TODO: SupplyLevelが3割を切ったため腹ペコモードにアニメーションを切り替える
                        }
                    }
                });
                
            }

            // SquadがBase内にいる場合1日でSupplyがすべて回復する
            var tick = dayLengthSecond / GameManager.AddTimeSeconds; ;
            GameManager.DataSavingController.MyArmyData.squads.ForEach(s =>
            {
                if (!s.isOnMap)
                {
                    // Squadが基地内にいる場合
                    s.supplyLevel += s.MaxSupply / tick;
                }
                else if (s.isOnMap && s.MapLocation != null && s.MapLocation.data.type == LocationParamter.Type.friend)
                {
                    // SquadはMap上だが友好的拠点の上にいる場合 基地内にいる場合より通常ゆっくり回復
                    s.supplyLevel += (s.MaxSupply / tick) * parameter.RecoveringSupplyRateWhenStayOnBase;
                }
                if (s.supplyLevel > s.MaxSupply)
                    s.supplyLevel = s.MaxSupply;
            });

            
        }

        /// <summary>
        /// ゲーム内で1分経過したときに呼び出し 非同期
        /// </summary>
        /// <param name="o"></param>
        /// <param name="args"></param>
        private void AddTimeNortificationAsync(object o, EventArgs args)
        {
            infoPanel.UpdateCards();
        }


        #region Squad and location
        /// <summary>
        /// Squadの内容に準じて出撃準備状態のSquadをmap上に配置する
        /// </summary>
        /// <param name="squad"></param>
        internal MapSquad SetSquadToReadyToGo(Squad squad)
        {
            var obj = Instantiate(squad.commander.MiniPrefab, Vector3.zero, transform.rotation, transform);
            ReadySquad = obj.GetComponent<MapSquad>();
            ReadySquad.data = squad;
            ReadySquad.IsSpawnMode = true;
            infoPanel.AddWithAnimation(ReadySquad);
            return ReadySquad;
        }

        /// <summary>
        /// Ready状態になっているSquadをlocationにスポーンさせる
        /// </summary>
        internal MapSquad PutReadySquadOnLocation(MapLocation location)
        {
            if (!IsSquadReadyToGo) return null;

            var newSquad = ReadySquad;

            newSquad.transform.position = location.transform.position;
            newSquad.SquadReachedOnSpawnPoint = SquadReachedOnSpawnPoint;
            newSquad.mapLocations = MapLocations;
            newSquad.isOnLocation = true;
            squads.Add(ReadySquad);
            newSquad.IsSpawnMode = false;
            newSquad.data.isOnMap = true;
            ReadySquad = null;

            infoPanel.SetInteractive(newSquad.data, true);

            UpdateLocations();

            SelectedSquad = newSquad;

            return newSquad;
        }

        /// <summary>
        /// Hierarchy上にSquadのObjectを作成し、その部隊のParameterをsetする
        /// </summary>
        /// <param name="squad">Squadの情報 nullの場合テスト用の部隊が作成される</param>
        /// <param name="isControllable">Squadが操作可能なSquadかどうか</param>
        /// <returns></returns>
        internal IEnumerator PutSquadOnMap(Squad squad, MapLocation location)
        {
            yield return StartCoroutine(_PutSquadOnMap(squad, location.transform.position));
        }

        /// <summary>
        /// Hierarchy上にSquadのObjectを作成し、その部隊のParameterをsetする
        /// </summary>
        /// <param name="squad">Squadの情報 nullの場合テスト用の部隊が作成される</param>
        /// <param name="isControllable">Squadが操作可能なSquadかどうか</param>
        /// <returns></returns>
        internal IEnumerator PutSquadOnMap(Squad squad, string locationId = null)
        {
            if (locationId != null)
            {
                var location = MapLocations.GetLocationFromID(locationId);
                if (location == null)
                    location = MapLocations.locations.First();
                yield return StartCoroutine(_PutSquadOnMap(squad, location.transform.position));
            }
            else
            {
                yield return StartCoroutine(_PutSquadOnMap(squad));
            }
        }

        /// <summary>
        /// Hierarchy上にSquadのObjectを作成し、その部隊のParameterをsetする
        /// </summary>
        /// <param name="squad">Squadの情報 nullの場合テスト用の部隊が作成される</param>
        /// <param name="isControllable">Squadが操作可能なSquadかどうか</param>
        /// <returns></returns>
        private IEnumerator _PutSquadOnMap(Squad squad, Vector3? location = null)
        {

            squad.isOnMap = true;

            GameObject obj = null;
            RectTransform panel = null ;
            if (squad.commander.MiniPrefab == null)
            {
                PrintWarning($"miniPrefab of commander {squad.commander.Name} is null");
                var handle = Addressables.LoadAssetAsync<GameObject>("TestSquad");
                panel = Instantiate(squadPanelTemplate.gameObject, squadPanelParent.transform).GetComponent<RectTransform>();
                while (!handle.IsDone)
                    yield return null;
                obj = Instantiate(handle.Result, squad.location.ToVector3(), transform.rotation, transform);
            }
            else
            {
                obj = Instantiate(squad.commander.MiniPrefab, squad.location.ToVector3(), transform.rotation, transform);
            }
            
            obj.transform.position = location.GetValueOrDefault( squad.location.ToVector3() );
            obj.transform.localPosition = new Vector3(obj.transform.localPosition.x, 0, obj.transform.localPosition.z);
            
            var mapSquad = obj.GetComponent<MapSquad>();
            mapSquad.Panel = panel;
            mapSquad.SquadReachedOnSpawnPoint = SquadReachedOnSpawnPoint;
            mapSquad.mapLocations = MapLocations;
            mapSquad.data = squad;
            squads.Add(mapSquad);

            UpdateLocations();
        }

        /// <summary>
        /// SquadのParameterデータのSquadの位置を現在の状態に更新する
        /// </summary>
        internal void UpdateLocations()
        {
            foreach(var s in squads)
            {

                s.data.location = new SerializableVector3(s.transform.position);

                var location = MapLocations.IsSquadOnLocation(s);
                if (location != null)
                {
                    s.data.MapLocation = location;
                    s.isOnLocation = true;
                    //s.data.RoadID = "";
                    continue;
                }

                //var road = MapLocations.IsTargetOnRoad(s.transform);
                //if (road != null)
                //{
                //    s.data.MapLocation = null;
                //    s.isOnLocation = false;
                //    s.data.RoadID = road.id;
                //    continue; 
                //}

                //s.data.MapLocation = null;
                //s.isOnLocation = false;
                //s.data.RoadID = road.id;

                PrintWarning($"UpdateLocations: {s} is not on location or road."+ $"\n{s.transform}");
            }
        }

        /// <summary>
        /// SquadがSpawnLocationに到達したときの呼び出し
        /// </summary>
        /// <param name="spawnLocationID"></param>
        /// <param name="squad"></param>
        private void SquadReachedOnSpawnPoint(Roads.MapSpawnLocation mapSpawnLocation, MapSquad squad)
        {
            if (mapSpawnLocation.SpawnSquadOnLocation == null) return;

            var args = new EncountEventArgs();
            args.Player = squad.data;

            args.Enemy = mapSpawnLocation.SpawnSquadOnLocation.data;

            MapSpawns.Encount(mapSpawnLocation.SpawnSquadOnLocation, squad);

            encountEventHandler?.Invoke(this, args);
        }
        #endregion

        #region Squad moving
        /// <summary>
        /// 全てのSquadsの移動を一時停止する
        /// </summary>
        public void StopAllSquads()
        {
            UpdateLocations();
            pausedSquads = squads.FindAll((s) =>
            {
                if (!s.moveSequence.IsActive())
                    return false;
                return s.moveSequence != null && s.moveSequence.IsPlaying();
            });
            pausedSquads.ForEach(s => {
                if (s.moveSequence != null)
                    s.moveSequence.Pause();
            });
        }

        /// <summary>
        /// 一時停止したSquadsの移動を再開する
        /// </summary>
        public void StartAllSquads()
        {
            pausedSquads.ForEach(s => s.moveSequence.Play());
            pausedSquads.Clear();
        }

        /// <summary>
        /// SquadをアニメーションなしにLocationに移動させる
        /// </summary>
        internal void SquadMoveWithoutAnimation(Squad squad, LocationParamter location)
        {
            var mapSquad = squads.Find((s) => s.data == squad);
            if (mapSquad == null)
                PrintError($"Request {squad.name} but it doesn't exist on MapSquads");
            var mapLocation = MapLocations.locations.Find(l => l.data.Equals(location));
            if (mapLocation == null)
                PrintError($"Request {location.name} but it doesn't exits on MapLocations");

            mapSquad.MoveToWithoutAnimation(mapLocation.gameObject.transform.position);
            UpdateLocations();
        }

        /// <summary>
        /// Squadを位置しているBaseに帰還させる
        /// </summary>
        /// <param name="forced">Supply切れや敗北などで強制的に戻すアニメーションの場合</param>
        /// <param name="squad">帰還させる対象のSquad</param>
        public IEnumerator SquadReturnToBase(MapSquad squad, bool forced)
        {
            UpdateLocations();
            // TODO SquadをBaseに帰還させる

            if (_selectedSquad == squad)
                _selectedSquad = null;

            ReturnAnimPlaying = true;

            infoPanel.Remove(squad.data);

            squad.data.isOnMap = false;
            squad.data.MapLocation = null;
            squads.Remove(squad);
            pausedSquads.Remove(squad);
            // 帰還時アニメーションとか
            if (forced)
                yield return StartCoroutine(squad.AnimationReturnToBaseForced());
            else
                yield return StartCoroutine( squad.AnimationReturnToBase() );

            Destroy(squad.gameObject);

            ReturnAnimPlaying = false;
        }

        /// <summary>
        /// 指定したmapSquadをMap上から消す
        /// </summary>
        /// <param name="mapSquad"></param>
        internal void DespawnSquad(MapSquad mapSquad)
        {
            squads.Remove(mapSquad);
            infoPanel.Remove(mapSquad.data);
            if (ReadySquad == mapSquad)
                ReadySquad = null;
            if (_selectedSquad == mapSquad)
                _selectedSquad = null;
            mapSquad.data.isOnMap = false;
            Destroy(mapSquad.gameObject);
        }

        /// <summary>
        /// SquadをmapSpawnLocation上に設置する
        /// </summary>
        /// <param name="mapSpawnLocation"></param>
        /// <param name="squad"></param>
        public void PutSquadOnSpawnLocation(Roads.MapSpawnLocation mapSpawnLocation, MapSquad squad)
        {
            squad.transform.position = new Vector3(mapSpawnLocation.transform.position.x,
                                                   squad.transform.position.y,
                                                   mapSpawnLocation.transform.position.z);
            UpdateLocations();
        }

        readonly Vector3 smallPoint = new Vector3(0.005f, 0.005f, 0.005f);
        private void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            if (testRouteCheckPoints != null)
            {
                for (var i = 0; i < testRouteCheckPoints.Count; i++)
                {
                    Handles.Label(testRouteCheckPoints[i].position, $"{i}", passGuiStyle);
                }
            }
        }

        /// <summary>
        /// <c>squad</c>をMapLocationに移動させる
        /// </summary>
        /// <param name="squad"></param>
        /// <param name="to"></param>
        public void MoveSquad(MapSquad squad, MapLocation to)
        {
            squad.CancelMoveAnimation();

            var routeCheckPoints = new List<Transform>();
            //var startRoad = MapLocations.IsTargetOnRoad(squad.transform);
            //if (startRoad != null && (startRoad.cross01 == to.crossing || startRoad.cross02 == to.crossing))
            //{
            //    // Squadが位置しているRoadから目標のLocationが一本道でつながる
            //    routeCheckPoints = startRoad.GetCheckPoints(squad.transform)[to.crossing];
            //}
            //else if (startRoad != null)
            //{
            //    PrintWarning("Squad must be on a location");
            //    // SquadはRoadの上に位置している
            //    var routes = MapLocations.mapRoads.GetBetterRoute(startRoad, squad.transform.position, to.crossing);
            //    routeCheckPoints = new List<Transform> { squad.transform };
            //    var firstCrossing = startRoad.GetConnectedCrossing(routes.First());
            //    routeCheckPoints.AddRange(startRoad.GetCheckPoints(squad.transform)[firstCrossing]);
            //    // Print(string.Join(",", routes));
            //    routes.ForEach(r =>
            //    {
            //        List<Transform> checkpoints = new List<Transform>();
            //        if (r.checkPoints.First() == routeCheckPoints.Last())
            //            checkpoints = r.checkPoints.slice(1);
            //        else if (r.checkPoints.Last() == routeCheckPoints.Last())
            //            checkpoints = r.checkPoints.Reversed().slice(1);
            //        routeCheckPoints.AddRange(checkpoints);
            //        Print(r, string.Join(",", checkpoints));
            //    });
            //}
            //else
            //{
            //    // TODO SquadはLocationでもRoadでもない位置に存在する
            //}

            var location = MapLocations.IsSquadOnLocation(squad);
            if (location != null)
            {
                // SquadはLocationの上に位置している
                routeCheckPoints = new List<Transform> { location.crossing.transform };
                var roads = mapRoads.GetBetterRoute(location.crossing, to.crossing);
                roads.ForEach(r =>
                {
                    List<Transform> checkpoints = new List<Transform>();
                    if (r.checkPoints.First() == routeCheckPoints.Last())
                        checkpoints = r.checkPoints.slice(1);
                    else if (r.checkPoints.Last() == routeCheckPoints.Last())
                        checkpoints = r.checkPoints.Reversed().slice(1);
                    routeCheckPoints.AddRange(checkpoints);
                });
            }
            else
            {
                PrintWarning($"{squad} try move, but it's not on any location.");
            }

            testRouteCheckPoints = routeCheckPoints;

            routeCheckPoints.Add(to.transform);
            StartCoroutine(SelectedSquad.MoveAlong(routeCheckPoints, () => UpdateLocations()));
        }

        List<Transform> testRouteCheckPoints;
        // ! UnitのRoad上の中途半端な位置での停止機能を廃止してLocation上のみにしたため使っていない
        /// <summary>
        /// <c>squad</c>をMapの上のPositionに移動させる
        /// </summary>
        /// <param name="squad"></param>
        /// <param name="to"></param>
        //public void MoveSquad(MapSquad squad, Vector3 to)
        //{
        //    squad.CancelMoveAnimation();

        //    var routeCheckPoints = new List<Transform>();

        //    var goalCheckPoint = new GameObject($"Goal: {SelectedSquad}");
        //    goalCheckPoint.transform.parent = this.transform;
        //    goalCheckPoint.transform.position = to;

        //    UpdateLocations();

        //    var startRoad = MapLocations.mapRoads.GetRoadFromID(squad.data.RoadID);
        //    var location = squad.data.MapLocation;
        //    var goalRoad = MapLocations.IsTargetOnRoad(goalCheckPoint.transform);

        //    Print($"StartRoad: {startRoad}, Location: {location}, GoalRoad: {goalRoad}");

        //    // Print(location, startRoad, goalRoad);
        //    if (startRoad == goalRoad)
        //    {
        //        // 移動が一本の道の上で行われる場合
        //        routeCheckPoints.Add(squad.transform);
        //        routeCheckPoints.AddRange(goalRoad.GetCheckPoints(squad.transform.position, to));

        //    }
        //    else if (location != null && goalRoad != null && goalRoad.IsConnected(location.crossing))
        //    {
        //        // Squadの位置するLocationに接続する道の上にgoalが存在する場合
        //        // Print(goalRoad, "is connected to", location);

        //        routeCheckPoints = new List<Transform> { location.crossing.transform };
        //        var lastCrossing = goalRoad.GetCrossing(routeCheckPoints.Last());
        //        var toGoalCheckPoint = goalRoad.GetCheckPoints(to, lastCrossing).slice(1);
        //        routeCheckPoints.AddRange(toGoalCheckPoint);
        //    }
        //    else if (goalRoad != null && startRoad != null && goalRoad.IsConnected(startRoad))
        //    {
        //        // Squadの位置するstartRoadにgoalRoadがcrossingで接続されている
        //        // ------(start)----------<c>-----------(goal)-----------

        //        /// BUG routeCheckPointsのindex=0にstartPosition(Squadのtransform)が組み込まれていない
        //        var crossing = startRoad.GetConnectedCrossing(goalRoad);
        //        //routeCheckPoints.Add(squad.transform);
        //        routeCheckPoints.AddRange(startRoad.GetCheckPoints(squad.transform)[crossing]);
        //        routeCheckPoints.AddRange(goalRoad.GetCheckPoints(to, crossing).slice(1));

        //    }
        //    else if (location != null && goalRoad != null)
        //    {
        //        // SquadはCrossing(MapLocation)上に存在している
        //        // 現在の位置から近いCrossingからgoalに近いcrossingの道順リストを検索
        //        // Print("SearchRoute", to);
        //        var routes = MapLocations.mapRoads.GetBetterRoute(location.crossing, goalRoad, to);
        //        // Print(string.Join(",", routes));
        //        routeCheckPoints = new List<Transform> { location.transform };
        //        routes.ForEach(r =>
        //        {
        //            if (r.checkPoints.First() == routeCheckPoints.Last())
        //                routeCheckPoints.AddRange(r.checkPoints.slice(1));
        //            else
        //                routeCheckPoints.AddRange(r.checkPoints.Reversed().slice(1));
        //        });
        //        // print(string.Join(",", routeCheckPoints));
        //        var lastCrossing = goalRoad.GetCrossing(routeCheckPoints.Last());
        //        // Print(lastCrossing);
        //        var toGoalCheckPoint = goalRoad.GetCheckPoints(to, lastCrossing).slice(1);
        //        routeCheckPoints.AddRange(toGoalCheckPoint);
        //    }
        //    else if (startRoad != null && goalRoad != null)
        //    {
        //        // SquadはRoad上に存在している
        //        var routes = MapLocations.mapRoads.GetBetterRoute(startRoad, squad.transform.position, goalRoad, to);
        //        var checkPointsOnStartRoad = startRoad.GetCheckPoints(squad.transform);
        //        if (!checkPointsOnStartRoad.TryGetValue(routes.First().cross01, out var toStartCrossing))
        //            toStartCrossing = checkPointsOnStartRoad[routes.First().cross02];

        //        routeCheckPoints = new List<Transform>(toStartCrossing);
        //        routes.ForEach(r =>
        //        {
        //            if (r.checkPoints.First() == routeCheckPoints.Last())
        //                routeCheckPoints.AddRange(r.checkPoints.slice(1));
        //            else
        //                routeCheckPoints.AddRange(r.checkPoints.Reversed().slice(1));
        //        });
        //        var lastCrossing = goalRoad.GetCrossing(routeCheckPoints.Last());
        //        var toGoalCheckPoint = goalRoad.GetCheckPoints(to, lastCrossing).slice(1);
        //        routeCheckPoints.AddRange(toGoalCheckPoint);
        //    }
        //    else
        //    {
        //        // TODO SquadはLocationでもRoadでもない位置に存在する
        //        PrintWarning($"{squad} is not on location or road. \nstartRoad({startRoad}), location({location}), goalRoad({goalRoad})");
        //    }

        //    testRouteCheckPoints = routeCheckPoints;

        //    routeCheckPoints.Add(goalCheckPoint.transform);
        //    StartCoroutine(SelectedSquad.MoveAlong(routeCheckPoints, () => UpdateLocations()));
        //}

        /// <summary>
        /// SquadがSupply切れなどで基地に戻る時にMapSquadから呼び出される
        /// </summary>
        /// <param name="squad">対象のSquad</param>
        /// <param name="forced">帰還がSupply切れなどの強制的なものか</param>
        private void SquadReturnToNearBase(MapSquad squad, bool forced)
        {
            StartCoroutine(SquadReturnToBase(squad, forced));
        }
        #endregion
    }

    /// <summary>
    /// エンカウント内容をEventArgsとして送るための
    /// </summary>
    public class EncountEventArgs : EventArgs
    {
        /// <summary>
        /// エンカウントした場所のID ここからTactics画面のIDへと行く
        /// </summary>
        public string TacticsSceneID { get => Enemy.tacticsSceneID; }
        /// <summary>
        /// エンカウントしたときのPlayerの開始Tile位置
        /// </summary>
        public List<string> PlayerPositions { get => Enemy.playerTileIDs; }
        /// <summary>
        /// エンカウントした自軍
        /// </summary>
        public Squad Player;
        /// <summary>
        /// エンカウントした敵軍
        /// </summary>
        public SpawnSquadData Enemy;
    }
}